module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },

  theme: {
    fontFamily: {
      sans: ['"Zen Kurenaido"'],
    },
  },
};
