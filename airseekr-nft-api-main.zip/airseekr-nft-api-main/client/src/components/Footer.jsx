const Footer = () => {
  return (
    <div className="footer">
      <div className="container mx-auto h-16"></div>
    </div>
  );
};

export default Footer;
