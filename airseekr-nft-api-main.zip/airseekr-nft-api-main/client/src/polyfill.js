import { Buffer } from "buffer";

window.global = window;
global.Buffer = Buffer;
