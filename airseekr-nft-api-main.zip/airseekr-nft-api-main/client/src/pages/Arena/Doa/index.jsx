const Doa = () => {
  return <div>Dead or Alive</div>;
};

export default Doa;
