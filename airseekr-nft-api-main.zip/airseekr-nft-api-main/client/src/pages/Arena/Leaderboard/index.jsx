const Leaderboard = () => {
  return <div>Top-Notch</div>;
};

export default Leaderboard;
