const Records = () => {
  return <div>Records</div>;
};

export default Records;
