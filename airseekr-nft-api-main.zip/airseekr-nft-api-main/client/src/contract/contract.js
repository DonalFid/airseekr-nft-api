require("dotenv").config();

export const contractABI = require("./azuki_ABI.json");
