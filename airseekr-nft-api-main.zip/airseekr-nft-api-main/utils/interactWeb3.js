export const contractAddress = "0x7376771C144EB3c9d3aD2ffEFb1d7DE83751eE57";

export const subscribeEvent = () => {};
